<?php

include 'header.php';

?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-3" style="min-height:480px;">
            <div class="card">
                <div class="card-header">
                KATEGORI BUKU</div>
                <div class="card-body">
                <div class="row">
    <div class="col">
        <a href="add-kategori.php" class="btn btn-primary">Tambah</a>
    </div>
</div>

  <div class="row mt-5">
    <div class="col">
    <table class="table table-bordered table-striped">
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Action</th>
            </tr>
          <?php
 
        $data = mysqli_query($koneksi,"select * from category_tb");

      $no = 1;
                                  
        while ($d = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $d['name']; ?></td>
        <td>
        <a href="edit-kategori.php?id=<?php echo $d['id']; ?>" class="btn btn-warning">edit</a>
		<a href="hapus-kategori.php?id=<?php echo $d['id']; ?>" class="btn btn-danger">hapus</a>
        </td>
    </tr>
    <?php
        }
    ?>

    </table>
    </div>
    </div>



                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';