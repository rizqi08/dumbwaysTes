<?php 
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$judul = $_POST['nama'];
$kategori = $_POST['category_id'];
$penulis = $_POST['writer_id'];
$tahunterbit = $_POST['publication_year'];

// update data ke database
mysqli_query($koneksi,"update book_tb set nama='$judul', category_id='$kategori', writer_id='$penulis', publication_year='$tahunterbit' where id='$id'");

// mengalihkan halaman kembali ke index.php
header("location:index.php");

?>