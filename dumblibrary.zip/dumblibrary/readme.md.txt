Database : dumb
software: xampp, vscode,browser
pemrograman PHP
