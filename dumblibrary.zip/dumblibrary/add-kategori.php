<?php
    include "header.php";

    $nama_kategori = $_POST['name'];

    mysqli_query($koneksi, "insert into category_tb values('', '$nama_kategori')");

    header("location:kategori.php");
?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-3" style="min-height:480px;">
            <div class="card">
                <div class="card-header">
                TAMBAH KATEGORI</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <label>Nama Kategori</label>
                                    <input type="text" class="form-control" name="name">
                                    <tr>
                                    
                                </div>
                                    <input type="submit" class="btn btn-primary" value="simpan">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include "footer.php";
?>