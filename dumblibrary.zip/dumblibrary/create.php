<?php
    include "koneksi.php";
    
    $judul = $_POST['nama'];
    $kategori = $_POST['category_id'];
    $penulis = $_POST['writer_id'];
    $tahunterbit = $_POST['publication_year'];
    $gambar = $_FILES['img']['name'];

    mysqli_query($koneksi, "insert into book_tb values('', '$judul', '$kategori', '$penulis', '$tahunterbit', '$gambar')");

    header("location:index.php");
?>