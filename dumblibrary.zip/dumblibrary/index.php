<?php
    include "header.php";
?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mt-3" style="min-height:480px;">
            <div class="card">
                <div class="card-header">
                DAFTAR DATA BUKU</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <a href="tambah.php" class="btn btn-primary">Tambah</a>
                        </div>
                        <div class="col">
                            <form action="index.php" class="form-inline float-right" method="get">
                                <input type="text" class="form-control" name="cari" placeholder="cari data">
                                <input type="submit" class="btn btn-primary ml-2" value="Cari">
                            </form>
                        </div>
                    </div>
                    <?php
                        if(isset($_GET['cari'])){
                            $cari = $_GET['cari'];
                        }
                    ?>
                    <div class="row mt-5">
                        <div class="col">
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>NO</th>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Penulis</th>
                                    <th>Tahun Terbit</th>
                                    <th>Gambar</th>
                                    <th>Opsi</th>
                                </tr>
                                <?php
                                    if(isset($_GET['cari'])){
                                    $cari = $_GET['cari']; 
                                    $data = mysqli_query($koneksi,"select * from book_tb where nama like '%".$cari."%'");

                                  }else {
                                    $data = mysqli_query($koneksi,"select * from book_tb");
                                  }
                                  $no = 1;
                                  
                                  while ($d = mysqli_fetch_array($data)){
                                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $d['nama']; ?></td>
                                    <td><?php echo $d['category_id']; ?></td>
                                    <td><?php echo $d['writer_id']; ?></td>
                                    <td><?php echo $d['publication_year']; ?></td>
                                    <td>
                                      <img src="gambar/<?php echo $d['img']; ?> "
                                      width="80"></td>
                                    <td>
                                    <a href="edit.php?id=<?php echo $d['id']; ?>" class="btn btn-warning">edit</a>
					                <a href="hapus.php?id=<?php echo $d['id']; ?>" class="btn btn-danger">hapus</a>
                                    </td>
                                </tr>
                                <?php
                                  }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    include "footer.php";
?>